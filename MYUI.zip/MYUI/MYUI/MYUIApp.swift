//
//  MYUIApp.swift
//  MYUI
//
//  Created by JOEYCO-0072PK on 06/12/2021.
//

import SwiftUI

@main
struct MYUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
